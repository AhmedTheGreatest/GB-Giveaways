
$('.carousel').carousel({
  interval: 2000
})



function EnableMontBlanc() {
  var MONTBLANC = document.getElementById("Products-Pens");
  //MONTBLANC.style.visibility = "visible";
  MONTBLANC.style.display = "none";
  //MONTBLANC.style.width = "0px"
  //MONTBLANC.style.height = "0px"
}


function DisableMontBlanc() {
  var MONTBLANC = document.getElementById("Products-Pens");
  //MONTBLANC.style.visibility = "hidden";
  MONTBLANC.style.display = "flex";
  //MONTBLANC.style.width = oldWidth;
  //MONTBLANC.style.height = oldHeight;
}